# Weather Forecasting Application
I have created this application using Java langauge and Designing is done via XML.
I have used Volley for JSON parsing and getting weather information from weatherapi.com.
This application will access your GPS and provide current weather status, temperature, current weather conditiom and hourly weather forecast of the whole day which includes temperature and wind speed.
This app also have manual search feature through which you can get weather information about any place in the world.

Stay ahead of the weather with my innovative Java app that combines cutting-edge technology and user-friendly design. Access real-time GPS data to receive up-to-date weather information including temperature, weather conditions, and hourly forecasts. With a manual search feature, you can easily get weather updates for any location. I used Volley for seamless JSON parsing and sourced information from weatherapi.com. Stay prepared, stay informed with this must-have weather app.
